import React from 'react'
import{Route, Routes} from 'react-router-dom'

import AddressDetails from '../Components/patient_registration_components/AddressDetails'
import BankDetails from '../Components/patient_registration_components/BankDetails'
import Patient from '../Components/patient_registration_components/Patient'



export default function PatientAppRoutes() {
    return (
     <>
     <Routes>

     <Route path='/patient' element={<Patient/>}/>
     <Route path='/addressdetails' element={<AddressDetails/>}/>
     <Route path='/bankdetails' element={<BankDetails/>}/>
    

     </Routes>
     </>
    )
}