import React, { useState } from 'react';
import axios from 'axios';

function BankDetailsForm() {
  const [formData, setFormData] = useState({
    pancard_number: '',
    account_number: '',
    bank_name: '',
    branch_name: '',
    ifsc_code: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8000/patientreg/bankdetails/', formData)
      .then(response => {
        console.log('Data saved successfully:', response.data);
        // Optionally, you can reset the form after successful submission
        setFormData({
          pancard_number: '',
          account_number: '',
          bank_name: '',
          branch_name: '',
          ifsc_code: ''
        });
      })
      .catch(error => {
        console.error('Error saving data:', error);
      });
  };

  return (
    <div className="container">
      <h2>Bank Details Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="pancard_number">PAN Card Number:</label>
          <input
            type="text"
            className="form-control"
            id="pancard_number"
            name="pancard_number"
            value={formData.pancard_number}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="account_number">Account Number:</label>
          <input
            type="text"
            className="form-control"
            id="account_number"
            name="account_number"
            value={formData.account_number}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="bank_name">Bank Name:</label>
          <input
            type="text"
            className="form-control"
            id="bank_name"
            name="bank_name"
            value={formData.bank_name}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="branch_name">Branch Name:</label>
          <input
            type="text"
            className="form-control"
            id="branch_name"
            name="branch_name"
            value={formData.branch_name}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="ifsc_code">IFSC Code:</label>
          <input
            type="text"
            className="form-control"
            id="ifsc_code"
            name="ifsc_code"
            value={formData.ifsc_code}
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
}

export default BankDetailsForm;
