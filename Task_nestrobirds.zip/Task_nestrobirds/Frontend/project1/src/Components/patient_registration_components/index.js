import AddressDetails from "./AddressDetails";
import BankDetails from "./BankDetails";
import Claim from "./Claim";
import ClaimDocument from "./ClaimDocument";
import Patient from "./Patient";


export{AddressDetails,BankDetails,Claim,ClaimDocument,Patient}