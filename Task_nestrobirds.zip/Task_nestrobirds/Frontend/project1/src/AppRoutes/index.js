import PatientAppRoutes from "./PatientAppRoutes";


export {PatientAppRoutes}