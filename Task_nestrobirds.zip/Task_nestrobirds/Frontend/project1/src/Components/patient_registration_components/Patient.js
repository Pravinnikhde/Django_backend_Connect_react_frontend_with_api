import React from 'react';
import { useForm } from 'react-hook-form';
import axios from 'axios';

export default function Patient() {
  const { register, handleSubmit } = useForm();

  function savedata(data) {
    axios.post('http://127.0.0.1:8000/patientreg/Patient/', data)
      .then(response => {
        console.log('Data saved successfully:', response.data);
      })
      .catch(error => {
        console.error('Error saving data:', error);
      });
  }

  return (
    <div className="container">
      <form className="mt-5 pt-5 m-auto" onSubmit={handleSubmit(savedata)}>
        <div className="col-12 col-lg-4 m-auto">
          <h5 className="text-center mb-5">Admit Patient</h5>

          <input type="text" id="pfname" placeholder="Enter patient first name" className="form-control shadow-none rounded-0 mt-3" />
          <input type="text" id="plname" placeholder="Enter patient last name" className="form-control shadow-none rounded-0 mt-3" />
          <input type="text" id="pmname" placeholder="Enter patient middle name" className="form-control shadow-none rounded-0 mt-3" />

          <input type="number" id="page" placeholder="Enter patient age" className="form-control shadow-none rounded-0 mt-3" />
          <input type="number" id="pweight" placeholder="Enter patient weight" className="form-control shadow-none rounded-0 mt-3" />
          <input type="number" id="pheight" placeholder="Enter patient height" className="form-control shadow-none rounded-0 mt-3" />

          <div className="mt-3 mx-3 mb-1">Martial status :</div>
          <div className="form-check form-check-inline">
            <input type="radio" id="married" value="married" className="form-check-input" />
            <label htmlFor="married" className="form-check-label">Married</label>
          </div>
          <div className="form-check form-check-inline">
            <input type="radio" id="unmarried" value="unmarried" className="form-check-input" />
            <label htmlFor="unmarried" className="form-check-label">Unmarried</label>
          </div>
          <div className="form-check form-check-inline">
            <input type="radio" id="divorced" value="divorced" className="form-check-input" />
            <label htmlFor="divorced" className="form-check-label">Divorced</label>
          </div>
          <div className="form-check form-check-inline">
            <input type="radio" id="widow" value="widow" className="form-check-input" />
            <label htmlFor="widow" className="form-check-label">Widow</label>
          </div>

          <div className="mt-3 mx-3">Gender :</div>
          <div className="form-check form-check-inline">
            <input type="radio" id="male" value="male" className="form-check-input" />
            <label htmlFor="male" className="form-check-label">Male</label>
          </div>
          <div className="form-check form-check-inline">
            <input type="radio" id="female" value="female" className="form-check-input" />
            <label htmlFor="female" className="form-check-label">Female</label>
          </div>
          <div className="form-check form-check-inline">
            <input type="radio" id="other" value="other" className="form-check-input" />
            <label htmlFor="other" className="form-check-label">Other</label>
          </div>

          <div className="mt-3 mx-3">Patient Handicap :</div>
          <div className="form-check form-check-inline">
            <input type="radio" id="yes" value="true" className="form-check-input" />
            <label htmlFor="yes" className="form-check-label">Yes</label>
          </div>
          <div className="form-check form-check-inline">
            <input type="radio" id="no" value="false" className="form-check-input" />
            <label htmlFor="no" className="form-check-label">No</label>
          </div>

          <label htmlFor="pdob" className="mt-3 mx-3 mb-1">Patient DOB :</label>
          <input type="date" id="pdob" className="form-control shadow-none rounded-0" />

          <input type="text" id="po" placeholder="Enter patient occupation" className="form-control shadow-none rounded-0 mt-3" />
          <input type="number" id="padhar" placeholder="Enter patient aadhar no" className="form-control shadow-none rounded-0 mt-3" />

          <input type="submit" className="btn btn-outline-success mt-3" value="SAVE DATA" />
        </div>
      </form>
    </div>
  );
}
